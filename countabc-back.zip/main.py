import multiprocessing

# The address and port to bind to
bind = "0.0.0.0:8000"

# Number of worker processes (adjust based on your server's CPU cores)
workers = multiprocessing.cpu_count() * 2 + 1

# Use threads
threads = 2 * multiprocessing.cpu_count()
print(workers,threads)
# Set the application module
app_module = "server:app"  # Replace with your app module name
# print(app_module)